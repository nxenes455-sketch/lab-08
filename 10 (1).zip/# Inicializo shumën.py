# Inicializo shumën
shuma = 0.0

while True:
    # Merr input nga përdoruesi
    vlera = input("Vlera: ")

    # Kontrollo nëse përdoruesi ka shkruar 'stop'
    if vlera.lower() == "stop":
        break  # Ndalon ciklin nëse përdoruesi shkruan 'stop'

    try:
        # Përpiqu të konvertojë inputin në float
        numri = float(vlera)
        shuma += numri  # Shto vlerën në shumën totale
    except ValueError:
        # Nëse inputi nuk është numër, kapërcen dhe tregon mesazh gabimi
        print("Vlerë e pavlefshme")
        continue  # Vazhdon me iteracionin tjetër të ciklit

# Printo shumën e përllogaritur
print(f"Shuma: {shuma:.2f}")
