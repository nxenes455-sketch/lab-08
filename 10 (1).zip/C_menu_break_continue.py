while True:
    # Shfaq menu
    print("\nMenu:")
    print("1) Pershendetje")
    print("2) Katerkendeshi: perimeteri")
    print("3) Ndihme")
    print("0) Dalje")

    # Merr zgjedhjen nga përdoruesi
    zgjedhja = input("Zgjedhja: ").strip().lower()

    if zgjedhja == "1":
        print("Përshëndetje!")
    elif zgjedhja == "2":
        try:
            a = float(input("a= "))
            b = float(input("b= "))
            perimeteri = 2 * (a + b)
            print(f"Perimetri: {perimeteri:.2f}")
        except ValueError:
            print("Vlera e pavlefshme për a ose b")
            continue  # Kthehu te menuja nëse ka gabim në input
    elif zgjedhja == "3":
        print("Ky është një program për llogaritjen e perimetrit të një katërkëndëshi.")
    elif zgjedhja == "0":
        print("Duke dalë nga programi...")
        break  # Dal nga cikli dhe ndalo programin
    else:
        print("Zgjedhje e pavlefshme")
        continue  # Kthehu te menuja nëse zgjedhja është e pavlefshme
